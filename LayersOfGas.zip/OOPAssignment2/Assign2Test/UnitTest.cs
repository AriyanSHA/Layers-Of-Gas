using Microsoft.VisualBasic;
using OOPAssignment2;
namespace Assign2Test
{
    [TestClass]
    public class UnitTest
    {
        private bool check = true;
        private List<char>? atmoVars = null;
        private List<string>? Layers = null;
        [TestInitialize]
        public void Init()
        {
            atmoVars = new List<char> { 'O', 'T', 'S' };
            Layers = new List<string> { "Z", "X", "C" };
        }
        [TestMethod]
        public void CreateGastExceptionTest()
        {
            string invalidGasType = "Y";
            double thickness = 1.0;

            Assert.ThrowsException<ArgumentException>(() => GasFactory.CreateGas(invalidGasType, thickness));
        }
        #region IsTrueTEST
        [TestMethod]
        public void CheckThunderTEST()
        {
            Assert.IsNotNull(atmoVars);
            Assert.IsTrue(atmoVars.Count > 0);

            foreach (char ch in atmoVars)
            {
                if (ch == 'T')
                    Assert.IsTrue(Program.CheckThunder(ch,ref check));
            }
        }
        [TestMethod]
        public void CheckSunshineTEST()
        {
            Assert.IsNotNull(atmoVars);
            Assert.IsTrue(atmoVars.Count > 0);

            foreach (char ch in atmoVars)
            {
                if (ch == 'S')
                    Assert.IsTrue(Program.CheckSunshine(ch, ref check));
            }
        }
        [TestMethod]
        public void CheckOtherTEST()
        {
            Assert.IsNotNull(atmoVars);
            Assert.IsTrue(atmoVars.Count > 0);

            foreach (char ch in atmoVars)
            {
                if (ch == 'O')
                    Assert.IsTrue(Program.CheckOther(ch, ref check));
            }
        }
        [TestMethod]
        public void CheckOzoneTest()
        {
            Assert.IsNotNull(Layers);
            Assert.IsTrue(Layers.Count > 0);

            foreach (string st in Layers)
            {
                if (st == "Z")
                    Assert.IsTrue(Program.CheckOzone(st));
            }
        }
        [TestMethod]
        public void CheckOxygenTest()
        {
            Assert.IsNotNull(Layers);
            Assert.IsTrue(Layers.Count > 0);

            foreach (string st in Layers)
            {
                if (st == "X")
                    Assert.IsTrue(Program.CheckOxygen(st));
            }
        }
        [TestMethod]
        public void CheckCarbonDTest()
        {
            Assert.IsNotNull(Layers);
            Assert.IsTrue(Layers.Count > 0);

            foreach (string st in Layers)
            {
                if (st == "C")
                    Assert.IsTrue(Program.CheckCarbonD(st));
            }
        }
        #endregion IsTrueTEST

        #region IsNotTrueTEST
        [TestMethod]
        public void RevCheckThunderTEST()
        {
            Assert.IsNotNull(atmoVars);
            Assert.IsTrue(atmoVars.Count > 0);

            foreach (char ch in atmoVars)
            {
                if (ch != 'T')
                    Assert.IsFalse(Program.CheckThunder(ch, ref check));
            }
        }
        [TestMethod]
        public void RevCheckSunshineTEST()
        {
            Assert.IsNotNull(atmoVars);
            Assert.IsTrue(atmoVars.Count > 0);

            foreach (char ch in atmoVars)
            {
                if (ch != 'S')
                    Assert.IsFalse(Program.CheckSunshine(ch, ref check));
            }
        }
        [TestMethod]
        public void RevCheckOtherTEST()
        {
            Assert.IsNotNull(atmoVars);
            Assert.IsTrue(atmoVars.Count > 0);

            foreach (char ch in atmoVars)
            {
                if (ch != 'O')
                    Assert.IsFalse(Program.CheckOther(ch, ref check));
            }
        }
        [TestMethod]
        public void RevCheckOzoneTest()
        {
            Assert.IsNotNull(Layers);
            Assert.IsTrue(Layers.Count > 0);

            foreach (string st in Layers)
            {
                if (st != "Z")
                    Assert.IsFalse(Program.CheckOzone(st));
            }
        }
        [TestMethod]
        public void RevCheckOxygenTest()
        {
            Assert.IsNotNull(Layers);
            Assert.IsTrue(Layers.Count > 0);

            foreach (string st in Layers)
            {
                if (st != "X")
                    Assert.IsFalse(Program.CheckOxygen(st));
            }
        }
        [TestMethod]
        public void RevCheckCarbonDTest()
        {
            Assert.IsNotNull(Layers);
            Assert.IsTrue(Layers.Count > 0);

            foreach (string st in Layers)
            {
                if (st != "C")
                    Assert.IsFalse(Program.CheckCarbonD(st));
            }
        }
        #endregion IsNotTrueTEST
    }
}